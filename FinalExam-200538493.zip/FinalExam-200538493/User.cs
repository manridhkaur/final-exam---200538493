using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam_200538493
{
    internal abstract class User
    {
        public int userID;
        public string firstName;
        public string lastName;
        public string address;
        public string phoneNumber;

        public User()
        {
            firstName=string.Empty;
            lastName=string.Empty;
            address=string.Empty;
            phoneNumber=string.Empty;
        }

        public void PrintBorrowingHistory()
        {

        }

        public bool SendReminder()
        {
            return true;
        }
    }
}