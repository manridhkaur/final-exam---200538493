using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam_200538493
{
    internal class Borrowing: iDownloadable
    {
        public int ReferenceNumber;
        public string Usercardnumber;
        public DateTime StartDate;
        public DateTime EndDate;
        public bool PickedUp=false;
        public List<Resource> Resources;
        private static int _lastReferenceNumber = 0;

        public Borrowing(string userId, List<Resource> resources)
        {
            Usercardnumber = userId;
            Resources = resources;
            ReferenceNumber = GenerateUniqueReferenceNumber();
        }
        
        private int GenerateUniqueReferenceNumber()
    {
        _lastReferenceNumber++;
        return _lastReferenceNumber;
    }

        public string GenerateAccessLink()
        {
            return "#1223932323";
        }

        public void ReturnResources(DateTime date)
        {
            if (date > this.EndDate)
            {
                Console.WriteLine("Your Must Pay Fine!");
                this.PickedUp = true;
            }
            else
            {
                Console.WriteLine("Thank You!");
                this.PickedUp = true;
            }
        }
    }
}