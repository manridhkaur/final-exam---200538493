namespace FinalExam_200538493
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Standard obj=new Standard();

            obj.userID = 1;
            obj.firstName = "manridh";
            obj.lastName = "kaur";
            obj.address = "georgian johnson";
            obj.phoneNumber = "2786277368";
            obj.PostCode = "W34FG5";
            obj.LibraryCardNbr = "12345";

            Resource r1 = new Resource();
            r1.Title = "user";
            r1.Code = "98t1";
            r1.Description = "holy bible";
            r1.DatePublished = DateTime.Now;
            r1.Publisher = "all yough inc.";

            Resource r2 = new Resource();
            r1.Title = "johnson book";
            r1.Code = "Z101";
            r1.Description = "hello world";
            r1.DatePublished = DateTime.Now;
            r1.Publisher = "players inc.";

            List<Resource> resources=new List<Resource>();
            resources.Add(r1);
            resources.Add(r2);

            Borrowing b1 = new Borrowing(obj.userID.ToString(), resources);
            b1.StartDate = DateTime.Now;
            b1.EndDate = b1.StartDate.AddDays(10);


        }
    }
}